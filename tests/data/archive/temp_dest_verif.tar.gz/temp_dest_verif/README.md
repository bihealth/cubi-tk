# Project description

Terse project description

## Contacts and links

- P.I.: [Maxene Musterfrau](mailto:maxene.musterfrau@charite.de)
- Client contact: [Max Mustermann](mailto:max.mustermann@charite.de)
- CUBI contact: [Eric Blanc](mailto:eric.blanc@bih-charite.de)
- CUBI project leader: Eric Blanc
- SODAR project UUID: 00000000-0000-0000-0000-000000000000
- SODAR URL: https://sodar.bihealth.org/projects/00000000-0000-0000-0000-000000000000
- CUBI gitlab URL: https://cubi-gitlab.bihealth.org
- HPCC directory: <void>

## Project status

- Project name: project
- Start date: 1970-01-01
- Current status: Finished
- Total size: 57832 (following links: 61819)
- Total number of files (inodes): 30 (following links: 26)
- Total number of files in `.snakemake` directories: 2

## Public datasets files

List here the provenance of public files that were used during the project life cycle,
but that should *NOT* be archived with the rest of the project.

